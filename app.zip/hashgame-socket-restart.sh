#!/bin/bash
set -e

# 服务端口
port1=9510
port2=9512
# 服务ID
serverId1=1
serverId2=2
# nginx配置文件
nginxConfSocket=/www/server/panel/vhost/nginx/hashgamesocket.9509.conf # 用户链接端口

# 检测端口是否可访问
checkPort() {
  nc -zvw3 127.0.0.1 "$1" >/dev/null 2>&1
}

# 启动端口
startPort() {
  ./supervisorctl start "$1"-HASH_GAME_SOCKET_"$2":"$1"-HASH_GAME_SOCKET_"$2"_00
  ./supervisorctl start "$1"-PERIODS_SETTLEMENT_"$2":"$1"-PERIODS_SETTLEMENT_"$2"_00
  ./supervisorctl start "$1"-PUSH_LATEST_BLOCK_"$2":"$1"-PUSH_LATEST_BLOCK_"$2"_00
}

# 停止端口
stopPort() {
  ./supervisorctl stop "$1"-PUSH_LATEST_BLOCK_"$2":"$1"-PUSH_LATEST_BLOCK_"$2"_00
  ./supervisorctl stop "$1"-PERIODS_SETTLEMENT_"$2":"$1"-PERIODS_SETTLEMENT_"$2"_00
  # 睡眠2秒
  sleep 2s
  ./supervisorctl stop "$1"-HASH_GAME_SOCKET_"$2":"$1"-HASH_GAME_SOCKET_"$2"_00
}

cd /www/server/panel/pyenv/bin/

if ! checkPort $port1; then
  # 启动端口
  startPort $port1 $serverId1
  # 睡眠2秒
  sleep 1s
  # 修改nginx配置文件端口
  sed -i "s/:$port2/:$port1/g" $nginxConfSocket
  # 重启nginx
  nginx -s reload
  # 停止端口
  if checkPort $port2;then
    stopPort $port2 $serverId2
  fi

  echo $port1
else
  # 启动端口
  startPort $port2 $serverId2
  # 睡眠2秒
  sleep 1s
  # 修改nginx配置文件端口
  sed -i "s/:$port1/:$port2/g" $nginxConfSocket
  # 重启nginx
  nginx -s reload
  # 停止端口
  if checkPort $port1;then
    stopPort $port1 $serverId1
  fi
  echo $port2
fi


#ps -ef | grep bin/hyperf.php | grep -v grep | cut -c 9-16 | xargs kill -9