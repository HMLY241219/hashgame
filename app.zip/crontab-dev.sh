#!/bin/bash
while true
do
  # 这里放置你的任务命令
  php bin/hyperf.php bg-block:latest
  sleep 5
done