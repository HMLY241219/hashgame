<?php
// TdSlots
return [
    'cid'             => '3377win',//测试
//    'cid'             => '3377win',//正式

    'secret_token'             => 'e72a4850-1988-460f-96b0-d5179c0cfff2',//测试
//    'secret_token'             => 'e72a4850-1988-460f-96b0-d5179c0cfff2',//正式


    // 币种
    'currency'         => 'INR',


    'language'         => 'en',  //英语
//    'language'         => 'pt-BR',  //葡萄牙语


    //请求头
    'herder' => ["Content-Type: application/x-www-form-urlencoded"],


    // 接口请求地址 TODO::正式环境需要更换地址
    'api_url' => 'https://game-preprod.aviatrix.work', //测试
//    'api_url' => 'https://game-preprod.aviatrix.work', //正式

    //http://jiligames.com/plusplayer/PlusTrial/{gameId}/{lang}
    'fee_entry_address' => 'https://game-preprod.aviatrix.work', //测试试玩链接
//    'fee_entry_address' => 'https://game-preprod.aviatrix.work', //正式试玩链接


];





