<?php
return [
    'appId'             => 'TJWW',//测试
//    'appId'             => '',//正式

    'appSecret'        => 'u8oqnejmre51q', // 测试
//    'appSecret'        => '', // 正式



    'country'         => 'IN', //印度


    // 币种
    'currency'         => 'INR', //印度
//    'currency'         => 'BRL', //巴西


    'language'         => 'en',  //英语
//    'language'         => 'pt',  //葡萄牙语
//    'language'         => 'in',  //印地文



    // API
    'api_url' => 'https://w.apiext88.net/seamless', //测试
//    'api_url' => '',


    // API
    'game_url' => 'https://www.weimen99f.net', //测试
//    'game_url' => '',
];






