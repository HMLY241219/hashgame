<?php
// TdSlots
return [
    'CASINO_ID'             => 'sichuanbodaxinghuitechnology-int',//测试
//    'CASINO_ID'             => 'sichuanbodaxinghuitechnology',//正式


    'AUTH_TOKEN'             => 'gG3UjRtCDZr4qzhGu3CZMW5F',//测试
//    'AUTH_TOKEN'             => 'EdEMtLRXdsDBVYzv9w3wRGqm',//正式


    // 币种
    'currency'         => 'INR',


    'language'         => 'en',  //英语
//    'language'         => 'pt-BR',  //葡萄牙语


    //请求头
    'herder' => ["Content-Type: application/x-www-form-urlencoded"],


    // 接口请求地址 TODO::正式环境需要更换地址
    'api_url' => 'https://int.bgaming-system.com/a8r/sichuanbodaxinghuitechnology-int', //测试
//    'api_url' => 'https://bgaming-asia.com/a8r/sichuanbodaxinghuitechnology', //正式

    //http://jiligames.com/plusplayer/PlusTrial/{gameId}/{lang}
    'fee_entry_address' => 'https://int.bgaming-system.com/a8r/sichuanbodaxinghuitechnology-int', //测试试玩链接
//    'fee_entry_address' => 'https://demo.spribe.io/launch', //正式试玩链接


];





