<?php
// TdSlots
return [

    'game_en_name' => [
        '1002' => 'TeenPatti',
        '1003' => 'Teen Patti',
        '1502' => 'Wheel Of Fortune',
        '1503' => 'Dranon Tiger',
        '1504' => 'Lucky Dice',
        '1505' => 'Jhandi Munda',
        '1506' => 'WINGO',
        '1507' => 'King&Queen',
        '1508' => '3 Patti Bet',
        '2001' => 'Slots',
        '1509' => 'Andar Bahar',
        '1510' => 'Mine',
        '1511' => 'Blastx',
        '1512' => 'Mines',
        '1513' => 'Mines2',
        '1514' => 'Aviator',
        '1515' => 'Lucky Jet',
        '1516' => 'Rocket Queen',
    ],

];





