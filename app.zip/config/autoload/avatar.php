<?php
//客户端头像配置
return [
    1 => '/uploads/avatar/2024040715373178998318.png',
    2 => '/uploads/avatar/2024040715373978920079.png',
    3 => '/uploads/avatar/2024040715373978920079.png',
    4 => '/uploads/avatar/2024040715375178966079.png',
    5 => '/uploads/avatar/2024040715380178999783.png',
    6 => '/uploads/avatar/2024040715380978957575.png',
    7 => '/uploads/avatar/2024040715381678945783.png',
    8 => '/uploads/avatar/2024040715382378989846.png',
    9 => '/uploads/avatar/2024040715383078942768.png',
    10 => '/uploads/avatar/2024040715383678998568.png',
    11 => '/uploads/avatar/2024040715385278992900.png',
    12 => '/uploads/avatar/2024040715385978936301.png',
    13 => '/uploads/avatar/2024040715390578932346.png',
    14 => '/uploads/avatar/2024040715391178964926.png',
    15 => '/uploads/avatar/2024040715391778961833.png',
    16 => '/uploads/avatar/2024040715392478901690.png',
];
