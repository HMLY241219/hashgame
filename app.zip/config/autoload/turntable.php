<?php
// 转盘
return [

    'money' => 300,
    'one_start_money' => 290,
    'one_end_money' => 293,
    'range_money' => [30000,50000,100000,500000],
    'range_zs_money' => [
        [0.1,0.2],
        [0.2,0.5],
        [0.3,0.5],
        [0.4,1],
        [0.5,1],
    ],
];





