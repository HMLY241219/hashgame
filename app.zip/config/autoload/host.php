<?php
return [
    'ip' => '172.17.0.4',  //redis地址
    'adminDomain' => 'http://1.13.81.132:5009',  //客户端图片返回的地址
    'apiDomain' => 'http://0.0.0.0:9502',  //客户端图片返回的地址
    'gameurl' => 'http://124.221.1.74',  //三方返回客户端的游戏URL
    'port0' => 6379,
    'port1' => 6501,
    'port2' => 6502,
];
