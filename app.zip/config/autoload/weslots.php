<?php
return [
    'operatorID'             => 'win7788m9r0n',//测试
//    'operatorID'             => 'win3377qJysY',//正式

    'appSecret'        => 'HaF2LTobxEmpdqGlnuExpJ', // 测试密码
//    'appSecret'        => '00BTOJdrGMGyGCd00VBI2O', // 密码


    // 币种
    'currency'         => 'INR', //印度
//    'currency'         => 'BRL', //巴西


    'language'         => 'en',  //英语
//    'language'         => 'pt',  //葡萄牙语
//    'language'         => 'in',  //印地文


    //请求头
    'herder' => ["Content-Type: application/x-www-form-urlencoded"],


    // 接口请求地址 TODO::正式环境需要更换地址
    'api_url' => 'https://uat-nc-ugs-weop.ufweg.com', //测试
//    'api_url' => 'https://nc-ugs-weop.ms16618.com',

];

