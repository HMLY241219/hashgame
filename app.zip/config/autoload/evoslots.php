<?php
return [
//    'operatorID'             => '10927001',//测试
////    'operatorID'             => '',//正式

    'casinoKey'        => 'kcwvn22elkrlqxjx', // 测试
//    'casinoKey'        => '2eisyx934zkulp8h', // 正式



    'apiToken'        => '4c784e6f1cb43f7bad8d3e1fcef9c459', // 测试
//    'apiToken'        => 'b68ce134911c110167005ea69d982505', // 正式


    'authToken'        => '4c784e6f1cb43f7bad8d3e1fcef9c459', // 测试
//    'authToken'        => 'b68ce134911c110167005ea69d982505', // 正式


    'country'         => 'IN', //印度



    // 币种
    'currency'         => 'INR', //印度
//    'currency'         => 'BRL', //巴西


    'language'         => 'en',  //英语
//    'language'         => 'pt',  //葡萄牙语
//    'language'         => 'in',  //印地文


    //请求头
    'herder' => ["Content-Type: application/x-www-form-urlencoded"],


    // API
    'api_url' => 'http://staging.evolution.asia-live.com', //测试
//    'api_url' => 'https://api.luckylivegames.com',


    // 游戏列表API
    'game_list_api' => 'https://site-stag-api.nimstad99.com', //测试
//    'game_list_api' => 'https://site-api.nimstad99.com', //正式


    // 游戏列表API
    'game_history_api' => 'https://stage-admin.asia-live.com', //测试
//    'game_history_api' => 'https://admin.luckylivegames.com', //正式
];



