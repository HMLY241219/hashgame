<?php
return [
    'com.win3377.Amzing' => [
        'accessToken' => 'EAAz6lcYgM40BOwyNcMzCaiYKrVT3resCzwcZBTk50Qo3yvi2GRQBDGT8fFEHTY09cOSsf4MMXjGldGkuj6UWd6G2752rv4ncmZA8QyLi9tghZAmQ9kVzNTqgAHkAqFwb4uUijkf5bBFRJGg6eGBmKrzVOTFFHEu7QqpqEh3cI8VWx7CBvzpZBI4azCopwxyRGQZDZD',
        'pixelId' => '513561564339738'
    ],
    'com.win3377.Amzingtwo' => [
        'accessToken' => 'EAAz6lcYgM40BOwyNcMzCaiYKrVT3resCzwcZBTk50Qo3yvi2GRQBDGT8fFEHTY09cOSsf4MMXjGldGkuj6UWd6G2752rv4ncmZA8QyLi9tghZAmQ9kVzNTqgAHkAqFwb4uUijkf5bBFRJGg6eGBmKrzVOTFFHEu7QqpqEh3cI8VWx7CBvzpZBI4azCopwxyRGQZDZD',
        'pixelId' => '513561564339738'
    ],
    //AmzingNew1
    '100030' => [
        'accessToken' => 'EAAG3ZCSYet1oBOz2bk5lnIZAZBnZBQybUT5pQBLax6TWCmUBIIENXcRujs1tuiEfKkdQVLP88wYJOiX3rpFwP1BBtMuu2uZCQ9dnVjbitWenW44eainWxPRL5bHQKHVwIw3RzsvjjkxQnAqjLxRi8wBZAQgsTAlo5jiMWXJG73F4OMUzJrAxjTmYqP9TJsMYLVpgZDZD',
        'pixelId' => '1715343422595188'
    ],
    //AmzingNew2
    '100040' => [
        'accessToken' => 'EAAGujys4vc8BOZBvCJrbKBvvOwPEpE3NXwLkoIwC7lINvLzFusJZC6FGwg1Yv6pyyJkrFHDA53Xw4kAsyGeaPQpTjJUV9shsr43kaprHf3kal2bgIasetOUMOY0xxYWFU5FoBZAYLOjNCnPTwKjm2NHGAyPnqeKMadrffSEWfIawT5f3FSIGAjpL9dzF72e1AZDZD',
        'pixelId' => '795901722739076'
    ],
    //AmzingNew3
    '100050' => [
        'accessToken' => 'EAAULQSfZCyEoBO0OZAQqrZBBAmeXQHRtBPJ1zN4BUGeQZCnGY02kDZAFDBX9bUwdeo2HQXz42qbYHiVZCgVp2SrHLn6xr1krVXMpJY07ZA8ufJCwYnVnnITtz6tRfdUln8ZAWSCl36ZCbjUviitCuZBOnD48oHqXmJAWNyNZAGNQTkCWJvyuTZB2NO1AYG6ddux5938AuAZDZD',
        'pixelId' => '372752095622486'
    ],
    //AmzingNew4
    '100060' => [
        'accessToken' => 'EAAOhDJw7gZCQBO6zv943WhmXu4QkZAH0CbVayCWp668Y7JBNOcpkaJjNyhZA3tpUYVYaFACQiOPFuqZB6TGdBOGkJ2qPrqEMlCBgrsG21vtbBKh6zFZCKLPhzVHp13M5iaBlNFpGOtEKFUJUFloMldvCYBAZAf1Su7rU3gXt3qf52xy0Rvr2ZBAEZBZBavuYaZC3HdKQZDZD',
        'pixelId' => '837762628453845'
    ],
    //AmzingNew5
    '100070' => [
        'accessToken' => 'EAAMjLbECVKMBO6aDIu7pLXbxYyFeCv6ZBznXWDxrXFrRR4PhS1fDjkOEqqZCKXwmjMHiXvf5dAZA68cwXw6CgSK9eN7jnYaZBai1nPU6NW2ZCedXUyiurZA5JOrQEDb1yPOfZAr33nkTmZAI3aXJXVmYC5RJqpon6YckGEZBqof98yagLIfAURTSgzaKOAEC6G1imdgZDZD',
        'pixelId' => '3692872964264115'
    ],
    //AmzingNew6
    '100080' => [
        'accessToken' => 'EAA3sq2ZBCuW4BOwSh55lx5SWxk8wJZBfh1VrlhEpd34aZAakLIuS9GrETw6PIZAQ101izBm7btV0Mud4mPffx6XkuffMo22aXZCU1qjrGXnyZBcAtA6WqpIhft86Wy1NujZCERyZCEU0d1OQOFw8YdyALV5WHMo6Y8nIA713M0lW9RCRYWkbgiKLpRt7QSqwlsTm0gZDZD',
        'pixelId' => '1731834937590182'
    ],
    //AmzingNew7
    '100090' => [
        'accessToken' => 'EAAigwAOL4M0BO8J2sS5mhw7DE5FgMIH8MpTqYDfnKsiBu9rHerAWzPEN3ZAEOWbcyWlTAQtTNa7EfAuFUFqwAUkTfoCwLsIpjQOoYralFRjwcKAkBZAI4FoGumloAvxmZCWXr385V0JcD3ZBmcvQBamBcuyMW6s42Rhv2J61kEbUWq7Q8ccl9QZArZCrOsSIlcAAZDZD',
        'pixelId' => '3610335705923935'
    ],
    //AmzingNew8
    '100100' => [
        'accessToken' => 'EAAOwSTHKvmUBO1j70b9n6KmL4eEasQNnH9giwJkWzjphyJ8vZCAFeinNShqmp4SvX5lHe8qi4p8XyZBR5tu8H2Wk1VKVj7Ec3kZC9qZB0R4zCscREMUVhZBZClNJHfKpOXQNoycPo9bYzMl7wWiULZB1W2AnWcqipwDOBSJxN0ot7bsMjYJQoNq9BKpvdoZA35VWyQZDZD',
        'pixelId' => '1188417388875777'
    ],
    //AmzingNew9
    '100110' => [
        'accessToken' => 'EAAOwSTHKvmUBOzRtD1RI6qMG4HMK79weULuPqZAZApM4oSJCC0dExKb8ZBhonKZAd7GfT59bikNEuvOv1QieFzPWZBa1Xn6lfhG6ZAGWdbi0yoacTJzd4iQxNz9p8Uhzf1Ih7a2L0C83n2s9Hqs0JwIEoHOZClRTwvNdZCqBKUFLJpaprgtwev5VjiRcdzLAMVp1tAZDZD',
        'pixelId' => '880820827286740'
    ],
    //AmzingNew10
    '100120' => [
        'accessToken' => 'EAAOwSTHKvmUBOzRtD1RI6qMG4HMK79weULuPqZAZApM4oSJCC0dExKb8ZBhonKZAd7GfT59bikNEuvOv1QieFzPWZBa1Xn6lfhG6ZAGWdbi0yoacTJzd4iQxNz9p8Uhzf1Ih7a2L0C83n2s9Hqs0JwIEoHOZClRTwvNdZCqBKUFLJpaprgtwev5VjiRcdzLAMVp1tAZDZD',
        'pixelId' => '1772674169933454'
    ],
    //com.win3377.mot
    'com.win3377.mot' => [
        'accessToken' => 'EAAXeCj0LaogBO17ZBL1FLhxZCLFpsM6KhF67Hozr6RZChb4UhjyYurFSf1Q2O2ThP7m1fRnJgtlliZAgDZAOK4wGZC2L42uTVuT5kXBMfCKqAOS2PmxQg5tpxzJcfUlfZCI2dBUTMWpz3y7nunGAcHaLfYBpfo10EI728GDaorAHVMqyB6MOjpQt7SIjhV6cCJxHgZDZD',
        'pixelId' => '1552339442372879'
    ],
    //AmzingNew11
    '100130' => [
        'accessToken' => 'EAAOwSTHKvmUBO1TT7usfjaIDhspNrEPvcMhBxuCu9AqkmMlNOsovM2KGH9ytO5PlvTdnWKQBf9O3WmcSJXXuZAZBTeZC2LXCJnAjvvQIO6iZCgDIa35im0CXUVRaZAHeSBdmmpAgoZCx6dTvanWS0chixXIpXmZBUNQTD87OCOYLZBs6rCkpK0eNjl7KEHhdRoDrIQZDZD',
        'pixelId' => '1882515938827003'
    ],
    //AmzingNew12
    '100140' => [
        'accessToken' => 'EAAOwSTHKvmUBO57rd4xeloHMitbQq8Wisu5k1U658mbX6HunpkX77SCKmkKAWZAA03gM7CAOoonpURL12yf9cFZAr9HCTiISsBLQBzk9r87mKsM6Uj7oZCyCCLVskxcULKlF66d2V3ZCb9m6BgZAiHp2IT9ZC0hD8jZBOIZAaFqzejlkMMKVqh3d3jcztZA573A9EewZDZD',
        'pixelId' => '4550460721844880'
    ],
    //Jkr
    '10080' => [
        'accessToken' => 'EAAMNMmNW94QBOwvxIfV9GKTDYwVALZAETZAZBWG6NR5U6PSDEEnMx0ZBHnLw0toeZBM25mVaFc0RkyzWoEPMARgW4nB3YslsAnCKL7qZAlB26URB7D0VT6sGZAKpkAm4w8xIWrqHxgwI0YS4yZAf8AlrpY9JbRZBiggKlz0VJaObED7Ttd43vnL07enGNW5WGoSsX2QZDZD',
        'pixelId' => '1085950476434655'
    ],
    //AmzingNew4fb
    '10090' => [
        'accessToken' => 'EAAOhDJw7gZCQBO6zv943WhmXu4QkZAH0CbVayCWp668Y7JBNOcpkaJjNyhZA3tpUYVYaFACQiOPFuqZB6TGdBOGkJ2qPrqEMlCBgrsG21vtbBKh6zFZCKLPhzVHp13M5iaBlNFpGOtEKFUJUFloMldvCYBAZAf1Su7rU3gXt3qf52xy0Rvr2ZBAEZBZBavuYaZC3HdKQZDZD',
        'pixelId' => '837762628453845'
    ],
    //AmzingNew5fb
    '10100' => [
        'accessToken' => 'EAAMjLbECVKMBO6aDIu7pLXbxYyFeCv6ZBznXWDxrXFrRR4PhS1fDjkOEqqZCKXwmjMHiXvf5dAZA68cwXw6CgSK9eN7jnYaZBai1nPU6NW2ZCedXUyiurZA5JOrQEDb1yPOfZAr33nkTmZAI3aXJXVmYC5RJqpon6YckGEZBqof98yagLIfAURTSgzaKOAEC6G1imdgZDZD',
        'pixelId' => '3692872964264115'
    ],
    //AmzingNew8fb
    '10110' => [
        'accessToken' => 'EAAOwSTHKvmUBO1j70b9n6KmL4eEasQNnH9giwJkWzjphyJ8vZCAFeinNShqmp4SvX5lHe8qi4p8XyZBR5tu8H2Wk1VKVj7Ec3kZC9qZB0R4zCscREMUVhZBZClNJHfKpOXQNoycPo9bYzMl7wWiULZB1W2AnWcqipwDOBSJxN0ot7bsMjYJQoNq9BKpvdoZA35VWyQZDZD',
        'pixelId' => '1188417388875777'
    ],
    //mot1fb
    '10120' => [
        'accessToken' => 'EAAXeCj0LaogBO17ZBL1FLhxZCLFpsM6KhF67Hozr6RZChb4UhjyYurFSf1Q2O2ThP7m1fRnJgtlliZAgDZAOK4wGZC2L42uTVuT5kXBMfCKqAOS2PmxQg5tpxzJcfUlfZCI2dBUTMWpz3y7nunGAcHaLfYBpfo10EI728GDaorAHVMqyB6MOjpQt7SIjhV6cCJxHgZDZD',
        'pixelId' => '1552339442372879'
    ],
    //mot2fb
    '10130' => [
        'accessToken' => 'EAAXeCj0LaogBO8ggrBZB762dgpZCwzCNMGE0Bl5RY3R2NbL4BZBl3zJL9TCe8Ig2ODTeMZC25sBlEUbRRMB2KGl2Ox1MPXDZCJzkZCZB7RKdENiqWqlS4STeaX6SNSHhlqWqDtceVetQp8KIYsuZBJDRXFchPTGRcQiVJMrSl6fi0pM8vGhusXo4SJdQIk2HJBZCNZBgZDZD',
        'pixelId' => '1675959523182560'
    ],
    //mot3fb
    '10140' => [
        'accessToken' => 'EAAKatsZBrvewBO6dvN28no8I2py8EorpZCEn6l20mbM8cpo9DONzhJ7D88rJhSZCI2gMTQ4qNVO27EMOBW2Dy4VFP4owHZAyxc3s4E8ZCTzz74TpBc4ZCWJT4x6ReJjUlE8feSqP4xw542q2nZAzeeo0XBWziLNIrel5RMoaZBslCLvWl7OdVPqxAWaIonfjSFDc3wZDZD',
        'pixelId' => '463063676729650'
    ],
    //AmzingNewfb
    '10150' => [
        'accessToken' => 'EAAz6lcYgM40BOwyNcMzCaiYKrVT3resCzwcZBTk50Qo3yvi2GRQBDGT8fFEHTY09cOSsf4MMXjGldGkuj6UWd6G2752rv4ncmZA8QyLi9tghZAmQ9kVzNTqgAHkAqFwb4uUijkf5bBFRJGg6eGBmKrzVOTFFHEu7QqpqEh3cI8VWx7CBvzpZBI4azCopwxyRGQZDZD',
        'pixelId' => '513561564339738'
    ],
    //AmzingNew2fb
    '10160' => [
        'accessToken' => 'EAAGujys4vc8BOZBvCJrbKBvvOwPEpE3NXwLkoIwC7lINvLzFusJZC6FGwg1Yv6pyyJkrFHDA53Xw4kAsyGeaPQpTjJUV9shsr43kaprHf3kal2bgIasetOUMOY0xxYWFU5FoBZAYLOjNCnPTwKjm2NHGAyPnqeKMadrffSEWfIawT5f3FSIGAjpL9dzF72e1AZDZD',
        'pixelId' => '795901722739076'
    ],
    //AmzingNew3fb
    '10170' => [
        'accessToken' => 'EAAULQSfZCyEoBO0OZAQqrZBBAmeXQHRtBPJ1zN4BUGeQZCnGY02kDZAFDBX9bUwdeo2HQXz42qbYHiVZCgVp2SrHLn6xr1krVXMpJY07ZA8ufJCwYnVnnITtz6tRfdUln8ZAWSCl36ZCbjUviitCuZBOnD48oHqXmJAWNyNZAGNQTkCWJvyuTZB2NO1AYG6ddux5938AuAZDZD',
        'pixelId' => '372752095622486'
    ],
    //AmzingNew6fb
    '10180' => [
        'accessToken' => 'EAA3sq2ZBCuW4BOwSh55lx5SWxk8wJZBfh1VrlhEpd34aZAakLIuS9GrETw6PIZAQ101izBm7btV0Mud4mPffx6XkuffMo22aXZCU1qjrGXnyZBcAtA6WqpIhft86Wy1NujZCERyZCEU0d1OQOFw8YdyALV5WHMo6Y8nIA713M0lW9RCRYWkbgiKLpRt7QSqwlsTm0gZDZD',
        'pixelId' => '1731834937590182'
    ],
    //Jkr1fb
    '10190' => [
        'accessToken' => 'EAAUUUZBZBSADQBOwXByfZCe8XHHqZAhsnLZClfaF5nkq4wGeAKL7SZAJ0F4todEyQDCyDgi61KvPiawHkhmMBZB7tnuban7glQE6g7A7Ev7ZAuOGgjDENyQXew9Cdi4zNpTuKIrjz55WKLNEfcnusez0puK6fony0CpsNZB3vnN2hasOXeW2EGzrMCGydsGYwCJWd1QZDZD',
        'pixelId' => '487167017576623'
    ],
    //jkr2fb
    '10200' => [
        'accessToken' => 'EAAUUUZBZBSADQBO255RBlsZB7f8RJSIqnZAJZBihM4HAZAS4ZANbiM5evuzQry0yerYaNxXOsvHaocRs6MquAhNjREdE3FthoYTqZBTgLAMXWLZC0bc1aZBdeiZAjGOAbdek5R7MOIvyhkNGjg7iO9M7yxZB4x28bOolWzYRSAYBpGgK6zHsiI2qrqHqwzlP98gsQjy3vQZDZD',
        'pixelId' => '1207229877079108'
    ],
    //jkr3fb
    '10210' => [
        'accessToken' => 'EAAUUUZBZBSADQBO3xaCacu14lNoZC06kU1lZAcOhBaFMFqkCfeOoGmvcIJJdhnkErHBpgdZCGP67ZCTWLLx4ef640CZAYgIZBxNoy3WvCAZAcpmFaOc5CyGc9io6rG8d3n8nzumfCtlKzjWvew1BeS1H0FZAxMcbrYwWiQWotC68wIdhpFsCkeE9oGjkn4DoAFYZARrCAZDZD',
        'pixelId' => '420669353840178'
    ],
    //AmzingNew13
    '100150' => [
        'accessToken' => 'EAAULQSfZCyEoBOzZBBkVCT8WMEmdYHVAXROli3RCHQHZAOYlmRDvBo01hbgZB5uZBsf1sMCAzDV5kcVBrSE2SVB5gWdgKynolL9dGWWnLN56gCAiV251ecVTmD0tejSG80Lv1sbQSx073ZByUtnB4fjH3Tw4ZA5BZAZAAqBSxQBPF3rtjfQxQU4hVkg9teInKZAFAwCgZDZD',
        'pixelId' => '864506242249911'
    ],
    //AmzingNew14
    '100160' => [
        'accessToken' => 'EAAULQSfZCyEoBOzZBBkVCT8WMEmdYHVAXROli3RCHQHZAOYlmRDvBo01hbgZB5uZBsf1sMCAzDV5kcVBrSE2SVB5gWdgKynolL9dGWWnLN56gCAiV251ecVTmD0tejSG80Lv1sbQSx073ZByUtnB4fjH3Tw4ZA5BZAZAAqBSxQBPF3rtjfQxQU4hVkg9teInKZAFAwCgZDZD',
        'pixelId' => '1474143350652194'
    ],
    //AmzingNew15
    '100170' => [
        'accessToken' => 'EAAigwAOL4M0BO5rdTLydVcxVAF1gHRjLLOxoRgZC7ZCZC80YIG2TJUweOrxqHel5cKahF66oTL0PbIpeCVqEAd18zPDU5rNYkZBFdG7yEFdyx4axT4ZAGpHet9JURJIhTLM32ejJJv693dDuIFGXBFLNdb41UzhtvgAmjjkLFORkgMLu51m7nobZBf5nGiCC0HRgZDZD',
        'pixelId' => '1214380686376810'
    ],
    //AmzingNew16
    '100180' => [
        'accessToken' => 'EAAigwAOL4M0BO5rdTLydVcxVAF1gHRjLLOxoRgZC7ZCZC80YIG2TJUweOrxqHel5cKahF66oTL0PbIpeCVqEAd18zPDU5rNYkZBFdG7yEFdyx4axT4ZAGpHet9JURJIhTLM32ejJJv693dDuIFGXBFLNdb41UzhtvgAmjjkLFORkgMLu51m7nobZBf5nGiCC0HRgZDZD',
        'pixelId' => '488605793939010'
    ],
    //MOT1
    '10220' => [
        'accessToken' => 'EAAXeCj0LaogBO17ZBL1FLhxZCLFpsM6KhF67Hozr6RZChb4UhjyYurFSf1Q2O2ThP7m1fRnJgtlliZAgDZAOK4wGZC2L42uTVuT5kXBMfCKqAOS2PmxQg5tpxzJcfUlfZCI2dBUTMWpz3y7nunGAcHaLfYBpfo10EI728GDaorAHVMqyB6MOjpQt7SIjhV6cCJxHgZDZD',
        'pixelId' => '1552339442372879'
    ],
    //MOT2
    '10230' => [
        'accessToken' => 'EAAXeCj0LaogBO8ggrBZB762dgpZCwzCNMGE0Bl5RY3R2NbL4BZBl3zJL9TCe8Ig2ODTeMZC25sBlEUbRRMB2KGl2Ox1MPXDZCJzkZCZB7RKdENiqWqlS4STeaX6SNSHhlqWqDtceVetQp8KIYsuZBJDRXFchPTGRcQiVJMrSl6fi0pM8vGhusXo4SJdQIk2HJBZCNZBgZDZD',
        'pixelId' => '1675959523182560'
    ],
    //MOT3
    '10240' => [
        'accessToken' => 'EAAMd5S6qwJkBOZCvQQEAZBiaMfhb62XfYI8aNkrSWWdmIp5PRymFrhQZBblTEa1HqgdbxfolzcKFMIjQuevYynrE9fwUck1biyzZCsHjY5d35Can2JYHuCLm06a70tmZAB51xyzR1YOf8qZBHyLGjkMgkKenm5jWLIWsGwmu5Ft9uimRf94omV8OUdP9BbKze8xgZDZD',
        'pixelId' => '1171306370764933'
    ],
    //Jkrnew1
    '10250' => [
        'accessToken' => 'EAAMNMmNW94QBOwvxIfV9GKTDYwVALZAETZAZBWG6NR5U6PSDEEnMx0ZBHnLw0toeZBM25mVaFc0RkyzWoEPMARgW4nB3YslsAnCKL7qZAlB26URB7D0VT6sGZAKpkAm4w8xIWrqHxgwI0YS4yZAf8AlrpY9JbRZBiggKlz0VJaObED7Ttd43vnL07enGNW5WGoSsX2QZDZD',
        'pixelId' => '1085950476434655'
    ],
    //Jkrnew2
    '10260' => [
        'accessToken' => 'EAAUUUZBZBSADQBOxKBJjJ6NmkkgK4yZAbAZAeNA72a6o7TpfpaI2KwOwgduLehTNkgcqtOmQsUuzaGuf9itoiPSoO15VPheF1KfiKxadljLMvTbmkPSfRTwDv6qUtCI9LqZAmMNzgN52hsze77uS1qoZCGoa7yJCQiMDRNLv7dqGDsiUspyAr1Bc6iiUH1RsRvVgZDZD',
        'pixelId' => '487167017576623'
    ],
    //Jkrnew3
    '10270' => [
        'accessToken' => 'EAAUUUZBZBSADQBO255RBlsZB7f8RJSIqnZAJZBihM4HAZAS4ZANbiM5evuzQry0yerYaNxXOsvHaocRs6MquAhNjREdE3FthoYTqZBTgLAMXWLZC0bc1aZBdeiZAjGOAbdek5R7MOIvyhkNGjg7iO9M7yxZB4x28bOolWzYRSAYBpGgK6zHsiI2qrqHqwzlP98gsQjy3vQZDZD',
        'pixelId' => '1207229877079108'
    ],
    //Jkrnew4
    '10280' => [
        'accessToken' => 'EAAUUUZBZBSADQBO3xaCacu14lNoZC06kU1lZAcOhBaFMFqkCfeOoGmvcIJJdhnkErHBpgdZCGP67ZCTWLLx4ef640CZAYgIZBxNoy3WvCAZAcpmFaOc5CyGc9io6rG8d3n8nzumfCtlKzjWvew1BeS1H0FZAxMcbrYwWiQWotC68wIdhpFsCkeE9oGjkn4DoAFYZARrCAZDZD',
        'pixelId' => '420669353840178'
    ],
    //LHG1
    '10290' => [
        'accessToken' => 'EAAX7qZBkaP9ABO4hpobpk1si8cSdtnFPTTi7N0ORiEdZCoiItKzMgEtR2GhZBkMOnstY4GxwBk6vmg33gAMUZCWh0AjDbaRlsnd15u8RLhAVvYw7ZC8wFe9rdeNCoOSdzXZAypJguuUFQKcFH5yOlQVG5GUzBZBbCxT1SX8BE5CqdvrsabeZA59i2Md83NSbZCMFt3wZDZD',
        'pixelId' => '2235562866797334'
    ],
    //LHG2
    '10300' => [
        'accessToken' => 'EAAVXV41CLJsBO1tq4U34MLxr06lBPkYRs0KLXwqzREF5Y0OYLZAe7kMA4pUZBZA1Sqvqc9AW14ZBSlk7EPIE95zvtHXttcFMitqgZBep3Tp8VbXXaxIMSpQt2MfVGGlGzYeSrFewSFocTs0b0qM2gZBdMuFXiaPIV21VZBV218cdrRHOr9mKVdhc5i2FTCNMHq9QAZDZD',
        'pixelId' => '1245792166579971'
    ],
    //JkrNewtwo2
    '140020' => [
        'accessToken' => 'EAAUUUZBZBSADQBOxKBJjJ6NmkkgK4yZAbAZAeNA72a6o7TpfpaI2KwOwgduLehTNkgcqtOmQsUuzaGuf9itoiPSoO15VPheF1KfiKxadljLMvTbmkPSfRTwDv6qUtCI9LqZAmMNzgN52hsze77uS1qoZCGoa7yJCQiMDRNLv7dqGDsiUspyAr1Bc6iiUH1RsRvVgZDZD',
        'pixelId' => '487167017576623'
    ],
    //JkrNewtwo3
    '140030' => [
        'accessToken' => 'EAAUUUZBZBSADQBO255RBlsZB7f8RJSIqnZAJZBihM4HAZAS4ZANbiM5evuzQry0yerYaNxXOsvHaocRs6MquAhNjREdE3FthoYTqZBTgLAMXWLZC0bc1aZBdeiZAjGOAbdek5R7MOIvyhkNGjg7iO9M7yxZB4x28bOolWzYRSAYBpGgK6zHsiI2qrqHqwzlP98gsQjy3vQZDZD',
        'pixelId' => '1207229877079108'
    ],
    //JkrNewtwo4
    '140040' => [
        'accessToken' => 'EAAUUUZBZBSADQBO3xaCacu14lNoZC06kU1lZAcOhBaFMFqkCfeOoGmvcIJJdhnkErHBpgdZCGP67ZCTWLLx4ef640CZAYgIZBxNoy3WvCAZAcpmFaOc5CyGc9io6rG8d3n8nzumfCtlKzjWvew1BeS1H0FZAxMcbrYwWiQWotC68wIdhpFsCkeE9oGjkn4DoAFYZARrCAZDZD',
        'pixelId' => '420669353840178'
    ],
    //Lhgnew1
    '130020' => [
        'accessToken' => 'EAAX7qZBkaP9ABO4hpobpk1si8cSdtnFPTTi7N0ORiEdZCoiItKzMgEtR2GhZBkMOnstY4GxwBk6vmg33gAMUZCWh0AjDbaRlsnd15u8RLhAVvYw7ZC8wFe9rdeNCoOSdzXZAypJguuUFQKcFH5yOlQVG5GUzBZBbCxT1SX8BE5CqdvrsabeZA59i2Md83NSbZCMFt3wZDZD',
        'pixelId' => '2235562866797334'
    ],
    //Lhgnew2
    '130030' => [
        'accessToken' => 'EAAVXV41CLJsBO1tq4U34MLxr06lBPkYRs0KLXwqzREF5Y0OYLZAe7kMA4pUZBZA1Sqvqc9AW14ZBSlk7EPIE95zvtHXttcFMitqgZBep3Tp8VbXXaxIMSpQt2MfVGGlGzYeSrFewSFocTs0b0qM2gZBdMuFXiaPIV21VZBV218cdrRHOr9mKVdhc5i2FTCNMHq9QAZDZD',
        'pixelId' => '1245792166579971'
    ],
    //motnew1
    '110020' => [
        'accessToken' => 'EAAXeCj0LaogBO17ZBL1FLhxZCLFpsM6KhF67Hozr6RZChb4UhjyYurFSf1Q2O2ThP7m1fRnJgtlliZAgDZAOK4wGZC2L42uTVuT5kXBMfCKqAOS2PmxQg5tpxzJcfUlfZCI2dBUTMWpz3y7nunGAcHaLfYBpfo10EI728GDaorAHVMqyB6MOjpQt7SIjhV6cCJxHgZDZD',
        'pixelId' => '1552339442372879'
    ],
    //motnew2
    '110030' => [
        'accessToken' => 'EAAXeCj0LaogBO8ggrBZB762dgpZCwzCNMGE0Bl5RY3R2NbL4BZBl3zJL9TCe8Ig2ODTeMZC25sBlEUbRRMB2KGl2Ox1MPXDZCJzkZCZB7RKdENiqWqlS4STeaX6SNSHhlqWqDtceVetQp8KIYsuZBJDRXFchPTGRcQiVJMrSl6fi0pM8vGhusXo4SJdQIk2HJBZCNZBgZDZD',
        'pixelId' => '1675959523182560'
    ],
    //motnew3
    '110040' => [
        'accessToken' => 'EAAKatsZBrvewBO6dvN28no8I2py8EorpZCEn6l20mbM8cpo9DONzhJ7D88rJhSZCI2gMTQ4qNVO27EMOBW2Dy4VFP4owHZAyxc3s4E8ZCTzz74TpBc4ZCWJT4x6ReJjUlE8feSqP4xw542q2nZAzeeo0XBWziLNIrel5RMoaZBslCLvWl7OdVPqxAWaIonfjSFDc3wZDZD',
        'pixelId' => '463063676729650'
    ],
    //AmzingNew17
    '100190' => [
        'accessToken' => 'EAAigwAOL4M0BO1qVWePUzKtmceZB4qArXf8gXIONZC4bUDFvxodqVt6hnaJWT6zSIpJPw1opKdTqlN42OpRR3ITYa9PdjlnNZBeb9EOx7ZCFwpwNmzRKUJlJU5xKLDG2kFY9ZBMWkTfneimEl12qhySUSkLsElBBaPKBcK1hr9Lpj9jxxQ2B9o2vvZAoocPROcdQZDZD',
        'pixelId' => '26467160262898979'
    ],
    //AmzingNew18
    '100200' => [
        'accessToken' => 'EAAigwAOL4M0BO1qVWePUzKtmceZB4qArXf8gXIONZC4bUDFvxodqVt6hnaJWT6zSIpJPw1opKdTqlN42OpRR3ITYa9PdjlnNZBeb9EOx7ZCFwpwNmzRKUJlJU5xKLDG2kFY9ZBMWkTfneimEl12qhySUSkLsElBBaPKBcK1hr9Lpj9jxxQ2B9o2vvZAoocPROcdQZDZD',
        'pixelId' => '1048079337043780'
    ],
];
