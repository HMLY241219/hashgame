<?php
// EgSlots

return [
    'Platform' => '777Bet',

    'Agent'             => '777Bettest_INR',//测试
//    'Agent'             => '777Bet_INR',//正式

    'Password'         =>   '777BettestINR888',//测试
//    'Password'         =>   '777BetINR888',//正式

    'ServerId'         =>   '777Bet_INR',//测试
//    'ServerId'         =>   '777BetPor_INR',//正式


    'CompanyKey'             => '8643B4568C7341AE9EC3A04304B6FEFE',//测试
//    'CompanyKey'             => '9ED28AA867CC4B49AA4212EE62634FA6',//正式


    // 币种
    'Currency'         => 'INR',


    'language'         => 'en',  //英语
//    'language'         => 'pt-BR',  //葡萄牙语

    //请求头
    'herder' => ["Content-Type: application/x-www-form-urlencoded"],


    // 接口请求地址 TODO::正式环境需要更换地址
    'api_url' => 'https://ex-api-demo-yy.568win.com', //测试
//    'api_url' => 'https://ex-api-yy2.ttbbyyllyy.com',//正式

    //http://tadagaming.com/plusplayer/PlusTrial/{gameId}/{lang}
    //'fee_entry_address1' => 'https://d29juml4m9n88c.cloudfront.net/games/slot/%s/?lang=%s&curr=usd&hidefps=true&useIFrame=true&hideTxID=true', //试玩链接
    //'fee_entry_address2' => 'https://d29juml4m9n88c.cloudfront.net/games/crash/%s/?lang=%s&curr=usd&useIFrame=true', //试玩链接


];





