<?php
// TdSlots
return [
    'operator_key'             => '3377wincom',//测试
//    'operator_key'             => '3377win',//正式

    'GameApi_URL'            => 'https://secure-ga.staging.spribe.io/api/v3',//测试
    //'GameApi_URL'            => 'https://secure-ga.apac.spribegaming.com/api/v3',//正式

    'secret_token'             => '8mudPznBYNmUIl3qmzsRq7umFOIDjTlc',//测试
//    'secret_token'             => 'fWERpugoHnOLEZOrvqdDnORXicXPncLU',//正式


    // 币种
    'currency'         => 'INR',


    'language'         => 'en',  //英语
//    'language'         => 'pt-BR',  //葡萄牙语


    //请求头
    'herder' => ["Content-Type: application/x-www-form-urlencoded"],


    // 接口请求地址 TODO::正式环境需要更换地址
    'api_url' => 'https://dev-test.spribe.io/games/launch', //测试
//    'api_url' => 'https://cdnet-launch.apac.spribegaming.com', //正式

    //http://jiligames.com/plusplayer/PlusTrial/{gameId}/{lang}
    'fee_entry_address' => 'https://demo.spribe.io/launch', //测试试玩链接
//    'fee_entry_address' => 'https://demo.spribe.io/launch', //正式试玩链接


];





