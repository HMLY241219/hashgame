<?php
return [
    'is_carry_bonus' => 1,//进入三方游戏是否携带Bonus,1=是,0=否
    'is_zy_carry_bonus' => 1,//进入自研游戏是否携带Bonus,1=是,0=否
    'convert_bonus_bili' => 0.01,//Bonus转换比例
];
